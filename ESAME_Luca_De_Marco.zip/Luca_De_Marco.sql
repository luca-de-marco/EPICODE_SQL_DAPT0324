-- Creo il database ToysGroup

CREATE DATABASE ToysGroup;
USE ToysGroup;

-- Creo la tabella prodotti

CREATE TABLE Product (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    product_category VARCHAR(30),
    product_price DECIMAL(10,2)
);

-- Creo la tabella regione

CREATE TABLE Region (
    country_id INT PRIMARY KEY,
    country_name VARCHAR(50),
    region_name VARCHAR(50)    
);

-- Creo la tabella vendite 

CREATE TABLE Sales (
    sale_id INT PRIMARY KEY,
    sale_date DATE,
    sale_quantity INT,
    sale_price DECIMAL(10,2),
    product_id INT,
    country_id INT,
    FOREIGN KEY (product_id) REFERENCES Product (product_id),
    FOREIGN KEY (country_id) REFERENCES Region (country_id)
);

INSERT INTO Product (product_id, product_name, product_category, product_price) VALUES
(1, 'Macchinina', 'Veicoli', 9.99),
(2, 'Bambola', 'Figure', 14.99),
(3, 'Set Lego', 'Costruzioni', 29.99),
(4, 'Action Figure Batman', 'Figure', 19.99),
(5, 'Puzzle', 'Puzzle', 12.99),
(6, 'Gioco da Tavolo', 'Giochi', 24.99),
(7, 'Peluche', 'Peluche', 15.99),
(8, 'Pista da Corsa', 'Veicoli', 34.99),
(9, 'Drone', 'Elettronica', 59.99),
(10, 'Auto Radiocomandata', 'Elettronica', 49.99),
(11, 'Kit di Magia', 'Magia', 19.99),
(12, 'Set di Artigianato', 'Arti & Mestieri', 14.99),
(13, 'Blocchi da Costruzione', 'Costruzioni', 19.99),
(14, 'Treno Modellino', 'Veicoli', 39.99),
(15, 'Cucina Giocattolo', 'Giochi di Finzione', 89.99),
(16, 'Dondolo', 'All\'Aperto', 69.99),
(17, 'Altalena', 'All\'Aperto', 199.99),
(18, 'Scivolo', 'All\'Aperto', 99.99),
(19, 'Bicicletta', 'All\'Aperto', 149.99),
(20, 'Monopattino', 'All\'Aperto', 59.99);

-- Verifico che i records della tabella prodotti siano stati inseriti correttamente

SELECT product_id, product_name, product_category, product_price
FROM Product;

-- Popolo la tabella delle aree geografiche

INSERT INTO Region (country_id, country_name, region_name)
VALUES
  (1, 'Italia', 'Europa'),
  (2, 'Francia', 'Europa'),
  (3, 'Spagna', 'Europa'),
  (4, 'Germania', 'Europa'),
  (5, 'Regno Unito', 'Europa'),
  (6, 'Stati Uniti', 'Nord America'),
  (7, 'Canada', 'Nord America'),
  (8, 'Messico', 'Nord America'),
  (9, 'Brasile', 'Sud America'),
  (10, 'Argentina', 'Sud America'),
  (11, 'Cina', 'Asia'),
  (12, 'Giappone', 'Asia'),
  (13, 'India', 'Asia'),
  (14, 'Australia', 'Oceania'),
  (15, 'Nuova Zelanda', 'Oceania'),
  (16, 'Russia', 'Asia'),
  (17, 'Sudafrica', 'Africa'),
  (18, 'Egitto', 'Africa'),
  (19, 'Nigeria', 'Africa'),
  (20, 'Etiopia', 'Africa');
  
-- Verifico che i records della tabella regioni siano stati inseriti correttamente

SELECT country_id, country_name, region_name
FROM Region;
  
-- Popolo la tabella delle vendite
  
INSERT INTO Sales (sale_id, sale_date, sale_quantity, sale_price, product_id, country_id) VALUES
(1, '2020-01-01', 10, 99.90, 1, 1),
(2, '2020-01-02', 5, 74.95, 2, 20),
(3, '2021-01-03', 3, 89.97, 3, 3),
(4, '2021-01-04', 7, 139.93, 4, 14),
(5, '2021-01-05', 4, 51.96, 5, 5),
(6, '2022-01-06', 6, 149.94, 5, 16),
(7, '2022-01-07', 8, 127.92, 7, 7),
(8, '2022-01-08', 2, 69.98, 8, 8),
(9, '2022-01-09', 1, 59.99, 9, 9),
(10, '2022-01-10', 9, 449.91, 11, 10),
(11, '2023-01-11', 2, 39.98, 11, 11),
(12, '2023-01-12', 3, 44.97, 5, 1),
(13, '2023-01-13', 5, 99.95, 13, 13),
(14, '2023-01-14', 4, 159.96, 6, 4),
(15, '2023-01-15', 1, 89.99, 15, 15),
(16, '2023-01-16', 2, 139.98, 6, 16),
(17, '2023-01-17', 3, 599.97, 17, 7),
(18, '2023-01-18', 4, 399.96, 8, 1),
(19, '2023-01-19', 6, 899.94, 9, 19),
(20, '2023-01-20', 7, 419.93, 20, 2);

-- Verifico che i records della tabella vendite siano stati inseriti correttamente

SELECT sale_id, sale_date, sale_quantity, sale_price, product_id, country_id
FROM Sales;

/* 1. Verificare che i campi definiti come PK siano univoci. */

-- Verifico l'univocità della PK nella tabella Product (se corretto restituisce campo vuoto)
SELECT product_id, COUNT(*)
FROM Product
GROUP BY product_id
HAVING COUNT(*) > 1;

-- Verifico l'univocità della PK nella tabella Region (se corretto restituisce campo vuoto)
SELECT country_id, COUNT(*)
FROM Region
GROUP BY country_id
HAVING COUNT(*) > 1;

-- Verifico l'univocità della PK nella tabella Sales (se corretto restituisce campo vuoto)
SELECT sale_id, COUNT(*)
FROM Sales
GROUP BY sale_id
HAVING COUNT(*) > 1;

/* 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

SELECT 
    p.product_name,
    YEAR(s.sale_date) AS sale_year,
    SUM(s.sale_quantity * s.sale_price) AS total_revenue
FROM
    Product p
        INNER JOIN
    Sales s ON p.product_id = s.product_id
GROUP BY p.product_name , YEAR(s.sale_date);

/* 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. */

SELECT 
    r.country_name,
    YEAR(s.sale_date) AS sale_year,
    SUM(s.sale_price) AS total_revenue
FROM 
    Sales s
JOIN 
    Region r ON s.country_id = r.country_id
GROUP BY 
    r.country_name, YEAR(s.sale_date)
ORDER BY 
    sale_year ASC, total_revenue DESC;

/* 4. Qual è la categoria di articoli maggiormente richiesta dal mercato? */

SELECT 
    p.product_category,
    SUM(s.sale_quantity) AS total_quantity_sold
FROM 
    Sales s
JOIN 
    Product p ON s.product_id = p.product_id
GROUP BY 
    p.product_category
ORDER BY 
    total_quantity_sold DESC
LIMIT 1;

/* 5. Quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */

-- Utilizzo una LEFT JOIN e unisco le vendite ai prodotti

SELECT 
    p.product_id,
    p.product_name AS not_sold_products
FROM 
    Product p
LEFT JOIN 
    Sales s ON p.product_id = s.product_id
WHERE 
    s.sale_id IS NULL;

-- Utilizzo la condizione NOT EXISTS con una query innestata

SELECT 
    p.product_id,
    p.product_name AS not_sold_products
FROM 
    Product p
WHERE 
    NOT EXISTS (
        SELECT 1
        FROM Sales s
        WHERE s.product_id = p.product_id
    );

/* 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente). */

SELECT 
    p.product_id,
    p.product_name,
    MAX(s.sale_date) AS last_sale_date
FROM 
    Sales s
JOIN 
    Product p ON s.product_id = p.product_id
GROUP BY 
    p.product_id, p.product_name;
